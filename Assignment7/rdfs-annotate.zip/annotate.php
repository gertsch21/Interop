#!/usr/bin/php -q
<?php


function convert_to_XML($input_file) {
  $output = array();
  exec("rapper -i guess -o rdfxml -q $input_file", $output);
  return implode($output);
}
function convert_to_TTL($input_file) {
  $output = array();
  exec("rapper -i guess -o turtle -q $input_file", $output);
  return implode("\n\r", $output);
}

function annotate( $strData, $schema) {
  $schema = simplexml_load_string($schema);
  $data = simplexml_load_string($strData);
  $one_more_iteration = true;

  while($one_more_iteration) {
    $one_more_iteration = false;
    foreach ($schema->xpath("/rdf:RDF/rdf:Description[rdfs:*]") as $description) {
      foreach($description->xpath('rdfs:*') as $rdfs) {
        $rdfs_name = $rdfs->getName();

        $about = $description->attributes($GLOBALS['RDF_NS'])->about;
        $h = str_split($about, ((strrpos($about, "/") > strrpos($about, "#")) ? strrpos($about, "/") : strrpos($about, "#"))+1) ;
        $ab_ns=$h[0] ;
        $ab_elem=$h[1];

        $resource = (string) $rdfs->attributes($GLOBALS['RDF_NS'])->resource[0];
        if (!$resource) continue;
        $h = str_split($resource, ((strrpos($resource, "/") > strrpos($resource, "#")) ? strrpos($resource, "/") : strrpos($resource, "#"))+1) ;
        $res_ns=$h[0] ;
        $res_elem=$h[1];

        switch($rdfs_name) {
          case 'subClassOf':
            if(annotate_subClassOf($data, $ab_ns, $ab_elem, $res_ns, $res_elem)) $one_more_iteration = true;
            break;
          case 'subPropertyOf':
            if(annotate_subPropertyOf($data, $ab_ns, $ab_elem, $res_ns, $res_elem)) $one_more_iteration = true;
            break;
          case 'domain':
            if(annotate_domain($data, $ab_ns, $ab_elem, $res_ns, $res_elem)) $one_more_iteration = true;
            break;
          case 'range':
            if(annotate_range($data, $ab_ns, $ab_elem, $res_ns, $res_elem)) $one_more_iteration = true;
            break;
          case 'label':
          case 'comment':
            break;
          default:
            print "$rdfs_name not supported.\n";
        }
      }
    }
  }
  return $data->saveXML();
}


function annotate_subClassOf($data, $ab_ns, $ab_elem, $res_ns, $res_elem) {
  $changes = false;
  foreach ($data->xpath("/rdf:RDF/rdf:Description[rdf:type[@rdf:resource='$ab_ns$ab_elem']]") as $item) {
    $about = $item->attributes($GLOBALS['RDF_NS'])->about;
    $exists = $data->xpath("/rdf:RDF/rdf:Description[@rdf:about='$about']/rdf:type[@rdf:resource='$res_ns$res_elem']");
    if(!count($exists)) { 
      #print "\n=============================== SUBCLASSOF ============================================\n";
      #print "===== AB: $ab_elem RES: $res_elem\n";
      #print "===== about: $about \n";
      #print("/rdf:RDF/rdf:Description[@rdf:about='$about']/rdf:type[@rdf:resource='$res_ns$res_elem']\n");
      #print "===== created: Description rdf:about='$about' -> rdf:type rdf:resource=''$res_ns$res_elem \n";
      # <rdf:Description rdf:about="http://univie.ac.at/interop/data/#a1000700">
      #    <rdf:type rdf:resource="http://univie.ac.at/interop/schema/#Student"/>
      # </rdf:Description>
      $elem = $item->xpath("/rdf:RDF")[0]->addChild("Description", "", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $elem->addAttribute("rdf:about", "$about", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $inner = $elem->addChild("type", "", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $inner->addAttribute("rdf:resource", "$res_ns$res_elem", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $changes = true;
    }
  }
  return $changes;
  
}

function annotate_subPropertyOf($data, $ab_ns, $ab_elem, $res_ns, $res_elem) {
  $changes = false;
  $data->registerXPathNamespace('ab_schema', $ab_ns) ;
  foreach ($data->xpath("/rdf:RDF/rdf:Description[ab_schema:$ab_elem]") as $item) {
    #  <rdf:Description rdf:about="http://univie.ac.at/interop/data/#datab">
    #    <s:taughtBy rdf:resource="http://univie.ac.at/interop/data/#schiki"/>
    #  </rdf:Description>
    $about = $item->attributes($GLOBALS['RDF_NS'])->about;
    $item->registerXPathNamespace('ab_schema', $ab_ns) ;
    $data->registerXPathNamespace('res', $res_ns) ;
    $property_resource = (string) $item->xpath("ab_schema:$ab_elem/@rdf:resource")[0];
    $exists = $data->xpath("/rdf:RDF/rdf:Description[@rdf:about='$about']/res:$res_elem [@rdf:resource='$property_resource']");
    if(!count($exists)) { 
      #print "\n=============================== SUBPROPERTYOF =========================================\n";
      #print "===== AB: $ab_elem RES: $res_elem\n";
      #print "===== about: $about \n";
      #print "===== property_resource: $property_resource \n";
      #print("/rdf:RDF/rdf:Description[@rdf:about='$about']/res:$res_elem [@rdf:resource='$property_resource']\n");
      #print "===== created: Description rdf:about='$about' -> $res_ns:$res_elem rdf:resource='$property_resource' \n";
      #<rdf:Description rdf:about="http://univie.ac.at/interop/data/#intelligence">
      #  <dc:creator rdf:resource="http://univie.ac.at/interop/data/#rinders"/>
      #</rdf:Description>
      $elem = $item->xpath("/rdf:RDF")[0]->addChild("Description", "", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $elem->addAttribute("rdf:about", "$about", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $inner = $elem->addChild($res_elem, "", $res_ns);
      $inner->addAttribute("rdf:resource", $property_resource, "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $changes = true;
    }
  }
  return $changes;
}

function annotate_domain($data, $ab_ns, $ab_elem, $res_ns, $res_elem) {
  $changes = false;
  $data->registerXPathNamespace('ab_schema', $ab_ns) ;
  foreach ($data->xpath("/rdf:RDF/rdf:Description[ab_schema:$ab_elem]") as $item) {
    $about = $item->attributes($GLOBALS['RDF_NS'])->about;
    $exists = $data->xpath("/rdf:RDF/rdf:Description[@rdf:about='$about']/rdf:type[@rdf:resource='$res_ns$res_elem']");
    if(!count($exists)) { 
      #print "\n=============================== DOMAIN ================================================\n";
      #print "===== AB: $ab_elem RES: $res_elem\n";
      #print "===== about: $about \n";
      #print("/rdf:RDF/rdf:Description[@rdf:about='$about']/rdf:type[@rdf:resource='$res_ns$res_elem']\n");
      #print "===== created: Description rdf:about='$about' -> rdf:type rdf:resource=''$res_ns$res_elem \n";
      # <rdf:Description rdf:about="http://univie.ac.at/interop/data/#a1000700">
      #    <rdf:type rdf:resource="http://univie.ac.at/interop/schema/#Student"/>
      # </rdf:Description>
      $elem = $item->xpath("/rdf:RDF")[0]->addChild("Description", "", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $elem->addAttribute("rdf:about", "$about", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $inner = $elem->addChild("type", "", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $inner->addAttribute("rdf:resource", "$res_ns$res_elem", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $changes = true;
    }
  }
  return $changes;
}

function annotate_range($data, $ab_ns, $ab_elem, $res_ns, $res_elem) {
  $changes = false;
  $data->registerXPathNamespace('ab_schema', $ab_ns) ;
  foreach ($data->xpath("/rdf:RDF/rdf:Description[ab_schema:$ab_elem]") as $item) {
    $about = $item->attributes($GLOBALS['RDF_NS'])->about;
    $item->registerXPathNamespace('ab_schema', $ab_ns) ;
    $data->registerXPathNamespace('res', $res_ns) ;
    $property_resource = (string) $item->xpath("ab_schema:$ab_elem/@rdf:resource")[0];
    $exists = $data->xpath("/rdf:RDF/rdf:Description[@rdf:about='$property_resource']/rdf:type[@rdf:resource='$res_ns$res_elem']");
    if(!count($exists)) { 
      #print "\n=============================== RANGE ================================================\n";
      #print "===== AB: $ab_elem RES: $res_elem\n";
      #print "===== about: $about \n";
      #print "===== property_resource: $property_resource \n";
      #print("/rdf:RDF/rdf:Description[@rdf:about='$about']/rdf:type[@rdf:resource='$res_ns$res_elem']\n");
      # <rdf:Description rdf:about="http://univie.ac.at/interop/data/#a1000700">
      #    <rdf:type rdf:resource="http://univie.ac.at/interop/schema/#Student"/>
      # </rdf:Description>
      $elem = $item->xpath("/rdf:RDF")[0]->addChild("Description", "", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $elem->addAttribute("rdf:about", "$property_resource", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $inner = $elem->addChild("type", "", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $inner->addAttribute("rdf:resource", "$res_ns$res_elem", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
      $changes = true;
    }
  }
  return $changes;
}

$RDF_NS="http://www.w3.org/1999/02/22-rdf-syntax-ns#";

$input = convert_to_XML("data.ttl");
$schema = convert_to_XML("schema.ttl");
$annotated = annotate($input, $schema);
file_put_contents("annotated.xml", $annotated);
file_put_contents("annotated.ttl", convert_to_TTL("annotated.xml"));
?>
